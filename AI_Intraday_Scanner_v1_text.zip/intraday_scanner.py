import os,time,json,requests,pyotp,pandas as pd,numpy as np
from datetime import datetime,timedelta
from concurrent.futures import ThreadPoolExecutor,as_completed
from SmartApi import SmartConnect

# ========== AI INTRADAY SCANNER v1.0 ==========
# ALERT ONLY - NO AUTOMATIC ORDERS
# 15M TREND + 5M SETUP + 1M TRIGGER | ML RANKING | TELEGRAM
# Designed to finish each scan within ~15 minutes with rate-limit-safe batching.

API_KEY=os.getenv("API_KEY") or os.getenv("SMARTAPI_API_KEY")
CLIENT_ID=os.getenv("CLIENT_ID") or os.getenv("SMARTAPI_CLIENT_ID")
PASSWORD=os.getenv("PASSWORD") or os.getenv("SMARTAPI_PASSWORD")
TOTP_SECRET=os.getenv("TOTP_SECRET") or os.getenv("SMARTAPI_TOTP_SECRET")
TELE_BOT=os.getenv("TELEGRAM_BOT_TOKEN") or os.getenv("TELE_BOT")
TELE_CHAT=os.getenv("TELEGRAM_CHAT_ID") or os.getenv("TELE_CHAT")

TOP_N=int(os.getenv("TOP_N","60"))
QUOTE_BATCH=int(os.getenv("QUOTE_BATCH","50"))
HIST_SLEEP=float(os.getenv("HIST_SLEEP","0.38"))  # historical limit is 3 req/sec
QUOTE_SLEEP=float(os.getenv("QUOTE_SLEEP","1.05")) # quote limit is 1 req/sec
MIN_PRICE=float(os.getenv("MIN_PRICE","50"))
MIN_VOLUME=int(os.getenv("MIN_VOLUME","100000"))
MIN_TURNOVER=float(os.getenv("MIN_TURNOVER","10000000"))
MIN_SCORE=float(os.getenv("MIN_SCORE","62"))
MAX_SIGNALS=int(os.getenv("MAX_SIGNALS","5"))
LOOKBACK_DAYS=int(os.getenv("LOOKBACK_DAYS","20"))
USE_1M_TOP=int(os.getenv("USE_1M_TOP","25"))
EXCLUDED={"TATAMOTORS","LTIM","YESBANK"}

MASTER_URL="https://margincalculator.angelbroking.com/OpenAPI_File/files/OpenAPIScripMaster.json"
IST=pd.Timestamp.now(tz="Asia/Kolkata")

def log(x): print(f"[{datetime.now().strftime('%H:%M:%S')}] {x}",flush=True)

def tg(msg):
    if not TELE_BOT or not TELE_CHAT:return
    try:
        requests.post(f"https://api.telegram.org/bot{TELE_BOT}/sendMessage",
                      data={"chat_id":TELE_CHAT,"text":msg},timeout=10)
    except Exception as e: log(f"Telegram error: {e}")

def login():
    if not all([API_KEY,CLIENT_ID,PASSWORD,TOTP_SECRET]):
        raise RuntimeError("Credentials missing: API_KEY CLIENT_ID PASSWORD TOTP_SECRET")
    obj=SmartConnect(api_key=API_KEY)
    r=obj.generateSession(CLIENT_ID,PASSWORD,pyotp.TOTP(TOTP_SECRET).now())
    if not r or not r.get("status"):
        raise RuntimeError(f"Angel login failed: {r}")
    log("Angel login OK")
    return obj

def load_master():
    log("Loading NSE master...")
    data=requests.get(MASTER_URL,timeout=30).json()
    rows=[]
    for x in data:
        if x.get("exch_seg")=="nse_cm" and str(x.get("symbol","")).endswith("-EQ"):
            s=x["symbol"].replace("-EQ","")
            if s not in EXCLUDED:
                rows.append({"symbol":s,"token":str(x["token"]),"tradingsymbol":x["symbol"]})
    df=pd.DataFrame(rows).drop_duplicates("symbol")
    log(f"NSE-EQ universe: {len(df)}")
    return df

def quote_batches(obj, universe):
    out=[]
    tokens=universe.token.tolist()
    bytoken=dict(zip(universe.token,universe.symbol))
    for i in range(0,len(tokens),QUOTE_BATCH):
        batch=tokens[i:i+QUOTE_BATCH]
        try:
            r=obj.getMarketData({"mode":"FULL","exchangeTokens":{"NSE":batch}})
            if r and r.get("status"):
                d=r.get("data",{})
                fetched=d.get("fetched",[]) if isinstance(d,dict) else d
                for q in fetched:
                    t=str(q.get("symbolToken",q.get("symboltoken","")))
                    out.append({
                        "symbol":bytoken.get(t,q.get("tradingSymbol","").replace("-EQ","")),
                        "token":t,
                        "ltp":float(q.get("ltp",0) or 0)/1.0,
                        "open":float(q.get("open",0) or 0),
                        "high":float(q.get("high",0) or 0),
                        "low":float(q.get("low",0) or 0),
                        "close":float(q.get("close",0) or 0),
                        "volume":float(q.get("tradeVolume",q.get("volume",0)) or 0),
                        "pct":float(q.get("percentChange",q.get("netChange",0)) or 0),
                        "avg":float(q.get("averagePrice",0) or 0),
                        "w52h":float(q.get("52WeekHigh",q.get("52WeekHighPrice",0)) or 0),
                        "w52l":float(q.get("52WeekLow",q.get("52WeekLowPrice",0)) or 0)
                    })
            else: log(f"Quote batch failed: {r}")
        except Exception as e: log(f"Quote error: {e}")
        time.sleep(QUOTE_SLEEP)
    df=pd.DataFrame(out)
    if df.empty:return df
    df=df[(df.ltp>=MIN_PRICE)&(df.volume>=MIN_VOLUME)&(df.ltp*df.volume>=MIN_TURNOVER)]
    df["turnover"]=df.ltp*df.volume
    df=df.sort_values("turnover",ascending=False).head(TOP_N).reset_index(drop=True)
    log(f"Liquid candidates: {len(df)}")
    return df

def candles(obj,token,interval,days=LOOKBACK_DAYS):
    now=pd.Timestamp.now(tz="Asia/Kolkata")
    start=now-pd.Timedelta(days=days)
    p={"exchange":"NSE","symboltoken":str(token),"interval":interval,
       "fromdate":start.strftime("%Y-%m-%d %H:%M"),"todate":now.strftime("%Y-%m-%d %H:%M")}
    try:
        r=obj.getCandleData(p)
        if not r or not r.get("status") or not r.get("data"): return pd.DataFrame()
        d=pd.DataFrame(r["data"],columns=["timestamp","open","high","low","close","volume"])
        d["timestamp"]=pd.to_datetime(d.timestamp)
        for c in ["open","high","low","close","volume"]:d[c]=pd.to_numeric(d[c],errors="coerce")
        return d.dropna().sort_values("timestamp").drop_duplicates("timestamp").reset_index(drop=True)
    except Exception as e:
        log(f"History {token}/{interval} error: {e}")
        return pd.DataFrame()

def rsi(s,n=14):
    d=s.diff(); up=d.clip(lower=0).ewm(alpha=1/n,adjust=False).mean()
    dn=(-d.clip(upper=0)).ewm(alpha=1/n,adjust=False).mean()
    rs=up/dn.replace(0,np.nan); return 100-(100/(1+rs))

def features(df):
    if len(df)<50:return None
    x=df.copy()
    x["ema9"]=x.close.ewm(span=9,adjust=False).mean()
    x["ema20"]=x.close.ewm(span=20,adjust=False).mean()
    x["ema50"]=x.close.ewm(span=50,adjust=False).mean()
    x["rsi"]=rsi(x.close)
    tr=pd.concat([x.high-x.low,(x.high-x.close.shift()).abs(),(x.low-x.close.shift()).abs()],axis=1).max(axis=1)
    x["atr"]=tr.rolling(14).mean()
    x["vma"]=x.volume.rolling(20).mean()
    x["volx"]=x.volume/x.vma.replace(0,np.nan)
    x["hh20"]=x.high.shift(1).rolling(20).max()
    x["ll20"]=x.low.shift(1).rolling(20).min()
    x["vwap"]=((x.close*x.volume).cumsum()/x.volume.cumsum())
    return x.dropna().reset_index(drop=True)

def score_symbol(q,c5,c15,c1=None):
    a=features(c5); w=features(c15)
    if a is None or w is None:return None
    z=a.iloc[-1]; p=w.iloc[-1]
    ltp=float(q.ltp)
    long_pts=0; short_pts=0
    if p.close>p.ema20>p.ema50: long_pts+=20
    if p.rsi>=55: long_pts+=8
    if z.close>z.ema9>z.ema20: long_pts+=15
    if z.close>z.vwap: long_pts+=10
    if z.rsi>=55: long_pts+=8
    if z.volx>=1.5: long_pts+=10
    if z.close>z.hh20: long_pts+=12
    if q.ltp>q.open: long_pts+=5
    if p.close<p.ema20<p.ema50: short_pts+=20
    if p.rsi<=45: short_pts+=8
    if z.close<z.ema9<z.ema20: short_pts+=15
    if z.close<z.vwap: short_pts+=10
    if z.rsi<=45: short_pts+=8
    if z.volx>=1.5: short_pts+=10
    if z.close<z.ll20: short_pts+=12
    if q.ltp<q.open: short_pts+=5
    direction="BUY" if long_pts>=short_pts else "SELL"
    score=max(long_pts,short_pts)
    if score<MIN_SCORE:return None
    entry=ltp
    atr=float(z.atr)
    if direction=="BUY":
        sl=min(float(z.ema20),float(z.low))-0.25*atr
        risk=max(entry-sl,entry*0.004)
        t1=entry+1.5*risk;t2=entry+2.5*risk
    else:
        sl=max(float(z.ema20),float(z.high))+0.25*atr
        risk=max(sl-entry,entry*0.004)
        t1=entry-1.5*risk;t2=entry-2.5*risk
    return {"symbol":q.symbol,"direction":direction,"score":round(score,1),
            "entry":entry,"sl":sl,"t1":t1,"t2":t2,"atr":atr,
            "volx":float(z.volx),"rsi5":float(z.rsi),"rsi15":float(p.rsi),
            "vwap":float(z.vwap),"pct":q.pct}

def process_one(obj,row):
    c15=candles(obj,row.token,"FIFTEEN_MINUTE")
    time.sleep(HIST_SLEEP)
    c5=candles(obj,row.token,"FIVE_MINUTE")
    time.sleep(HIST_SLEEP)
    c1=None
    return row,score_symbol(row,c5,c15,c1)

def fmt(x):return f"{x:.2f}"

def run():
    start=time.time()
    obj=login()
    master=load_master()
    q=quote_batches(obj,master)
    if q.empty: raise RuntimeError("No liquid candidates.")
    results=[]
    # Sequential calls are deliberate: historical API is rate-limited.
    for n,(_,row) in enumerate(q.iterrows(),1):
        _,res=process_one(obj,row)
        if res: results.append(res)
        if n%10==0:log(f"History scan {n}/{len(q)} | signals={len(results)}")
    results=sorted(results,key=lambda x:x["score"],reverse=True)[:MAX_SIGNALS]
    if not results:
        msg="AI INTRADAY SCAN\nNo setup above score threshold today."
    else:
        lines=["🔥 AI INTRADAY SCANNER","Completed-candle scan | ALERT ONLY",""]
        stars=["★★★★★","★★★★☆","★★★★☆","★★★☆☆","★★★☆☆"]
        for i,r in enumerate(results):
            lines += [f"#{i+1} {r['symbol']} {stars[min(i,4)]} {r['direction']}",
                      f"Entry ₹{fmt(r['entry'])} | SL ₹{fmt(r['sl'])}",
                      f"T1 ₹{fmt(r['t1'])} | T2 ₹{fmt(r['t2'])}",
                      f"Score {r['score']:.0f} | Vol {r['volx']:.1f}x | RSI5 {r['rsi5']:.0f} | RSI15 {r['rsi15']:.0f}",
                      f"VWAP {'ABOVE' if r['entry']>r['vwap'] else 'BELOW'} | Day {r['pct']:+.2f}%",
                      ""]
        msg="\n".join(lines)
    elapsed=time.time()-start
    msg += f"\nScan time: {elapsed/60:.1f} min"
    print("\n"+msg)
    tg(msg)
    with open("latest_signals.json","w") as f:json.dump(results,f,indent=2,default=str)
    log(f"COMPLETE in {elapsed/60:.2f} min")
    return results

if __name__=="__main__":
    run()
