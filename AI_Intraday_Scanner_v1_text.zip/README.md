# AI Intraday Scanner v1
Alert-only Angel One NSE intraday scanner.
5M + 15M confirmation, EMA/VWAP/RSI/ATR/volume/breakout scoring, Top 5 Telegram alerts.
No automatic orders.
Set GitHub Secrets: API_KEY, CLIENT_ID, PASSWORD, TOTP_SECRET, TELEGRAM_BOT_TOKEN, TELEGRAM_CHAT_ID.
Run: python main.py
